
SELECT names FROM customers WHERE country='Hungary';